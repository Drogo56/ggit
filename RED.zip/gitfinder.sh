#!/bin/bash

THRDS=$2
if [[ -z $THRDS ]]; then THRDS=50; fi
cat $1 | httpx -debug -v -threads $THRDS -path '/.git/config' -match-string '[core]' -o vulns2.txt
sed -i 's/\/config$//g' vulns2.txt
