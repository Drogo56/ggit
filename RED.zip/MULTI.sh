#!/bin/bash
#sudo mv vulns_chek.txt vulns.txt
split -l 200 vulns.txt lol
for i in $(ls lol*); do nohup bash dumperz.sh $i &done&
