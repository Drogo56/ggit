# -*- coding: utf-8 -*-
#!/usr/bin/env python3

import sys
import requests
import random
from multiprocessing.dummy import Pool
import os
requests.urllib3.disable_warnings()
os.system('cls||clear')
print(r"""
 _______ __ _________        _      _____
|_____ /|  |  ___|  |       / \    /     \
   /  / |  | |___|  |      / _ \  |   O  |
  /  /  |  |  ___|  |     /  _  \ |   _  |
 /  /___|  | |   |  |____/  / \  \|  | \  \ 
/_______|__|_|   |______/__/   \__|__|  \__\
            MASS GIT FINDER
                              By Ziflar zemba
		""""\n")
try:
    domains = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    exit('Où est ta liste?')

def check(domain):
    resp = False
    try:
        headers = {'User-agent':'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.129 Safari/537.36'}
        get_source = requests.get('http://'+domain+'/.git/config', headers=headers, timeout=5, verify=False, allow_redirects=False).text
        if "[core]" in get_source:
           resp = get_source
           print(domain+"  \033[32;1mVuln\033[0m")
           with open("vulns.txt", "a+") as f:
            print('http://'+domain+'/.git', file=f)
        else:
                get_source = requests.get('https://'+domain+'/.git/config', headers=headers, timeout=5, verify=False, allow_redirects=False).text
                if "[core]" in get_source:
                  print(domain+"  \033[32;1mVuln\033[0m")
                  resp = get_source
                  with open("vulns.txt", "a+") as f:
                    print('https://'+domain+'/.git', file=f)

    except:
          print(domain+" \033[31;1mNot vul\033[0m")
          with open("Not_vulns.txt", "a+") as f:
            print(domain, file=f)
          pass

mp = Pool(100)
mp.map(check, domains)
mp.close()
mp.join()

